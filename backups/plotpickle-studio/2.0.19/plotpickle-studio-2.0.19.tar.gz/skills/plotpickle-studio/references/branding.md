# PlotPickle Studio branding

Use PlotPickle Studio as the product name. It is a human-led storytelling workspace in ChatGPT, guided by Elara. REEL develops films; ONCE preserves life stories. Describe the journey as Script → Storyboard → Visuals → Produce. Retain the existing approved logo, restrained purple palette, matte black/off-white Skin V1 design and four HOME choices: Meet Elara, Learn, Storyboard, Connected Services.

Public introduction: https://plotpickle.com/ . Workspace: https://studio.plotpickle.com/home . Website access with ChatGPT sign-in is separate from private plugin installation; do not claim a public-directory listing.

Describe the supported current-source workflow accurately: 81 lessons, screenplay-linked BEATs, storyboard candidates, verified motion and six-track editorial drafts. Locking an exact candidate includes human approval. Audio import, lock, placement and picture-and-sound rendering use the current editor workflow, with chat-side media-runtime execution. Automatic Library project loading and native PPF writeback are not implied. Keep personal stories and media out of marketing or plugin packages unless explicitly approved.

The legacy transfer description is not the product positioning. App-owned listing presentation is maintained separately from these skills; do not claim that a skill update changes that listing.
