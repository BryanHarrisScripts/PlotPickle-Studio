---
name: plotpickle-studio
description: ChatGPT-native PlotPickle Studio HOME, REEL, ONCE, saved stories, and verified, consistent Skin V1 views; no hosted sidebar.
---

## Current hosted core routing — November 11, 2026

Use `../plotpickle-studio/references/hosted-core.md` for the current Sites-hosted core and Elara handoff. This routing supersedes older source-only, independent-host migration, and mandatory separate Transfer setup descriptions. Keep the original plugin and App connection, the approved Skin V1 hierarchy, and the existing project truth rules. Elara converses in this ChatGPT conversation while the application runs beside it; do not add a website chatbot or request an API key for chat.

# PlotPickle Studio — ChatGPT-native workspace (v0.8.42)

**For EVERY approved Studio layout, first read `../plotpickle-skin-v1/SKILL.md` and `../plotpickle-skin-v1/references/skin-v1.json`.** Apply the canonical fixed surface order; never improvise a different HOME, Storyboard, Story Map, Mini-Block/25-Shot Grid or Image Review layout. V1 approvals are preserved in the owner's private ChatGPT Library register. Skin V1 is the current published design standard, not a standalone hosted UI runtime or a claim of identical pixels on every device.

HOME remains Meet Elara, Learn, Storyboard, Connected Services. Storyboard opens REEL (make a movie) or ONCE (preserve a life story), then verified saved stories. Both paths share the same source PPF, the 81 lessons, characters, worlds, source-linked shots, visual candidates, Save→Lock, fal motion on demand, audio, animatic, editor, posters, reports and production tools. There is no GitHub account, new storage service or Windows app requirement for ordinary ChatGPT operation.

Story Map, Shot Grid and Image Review are in-chat projections using validated current PPF and actual media. For read-only drilldown use `../plotpickle-navigator/SKILL.md`, and for Image Review use `../plotpickle-review/SKILL.md`. Source truth remains `../read-plotpickle-project/SKILL.md`. Show source location, project ID, revision and hash when verified, or explicit unknowns. Separate Human Approved, PPF Saved, PPF Locked and Media Verified. Never treat a selection toggle, draft mockup or conversation approval as a PPF write. Secure writes need current version guards, valid source and media, and a new saved project reopened to prove success.

Save/Lock transaction interface design is approved and standardized in `../plotpickle-skin-v1/references/save-lock-transaction.v1.json`. That does NOT implement or authorize transaction writes, batch auto-defaults or backend behavior. Exact mutation uses existing guarded tool-based workflows only when independently verified. Provider costs need explicit job-specific approval. Production Handoff Skin V1 layout and all remaining unapproved surfaces are pending; do not market those layouts as approved. Preserve other existing feature skill routes without new unapproved shells.

The retired standalone Studio sidebar pilot remains retired. If native in-chat controls are supported, render real, locally navigable sections; if not, keep identical text hierarchy. No invisible worker or automatic remote host.

## Published v0.8.38 nested presentations (retained unchanged)

When entering REEL show the approved `REEL_WORKSPACE_ENTRY` with four starting cards and verified Your Stories; not a new HOME category. When asked for mobile Storyboard/shot Review, apply `MOBILE_STORYBOARD_REVIEW` from Skin V1: 25 tap positions, genuine source image, four independent statuses and inactive controls unless a tool-backed write is available. The historical sidebar is an aesthetic reference only. The creator's five-panel reading workflow is in `../plotpickle-graphic-novel/SKILL.md`. Existing five-page editions may be read from the creator's private story Library after real file verification. Never package the private pages in this plugin, invent completed downstream pages, claim source PPF edits, or initiate paid media actions by simply viewing a layout. Production Handoff design and other pending surfaces remain unapproved.

## Published v0.8.39 — approved official ten-page reading route

In REEL > verified Your Stories > The Third Bell, present **Read Graphic Novel** as a child action when the actual private edition is accessible and verified. Route to `../plotpickle-official-reader/SKILL.md` for **Official Blocks 01–02** and offer ten sequential real pages, 5 vertically stacked captioned illustrations per page, native in-chat page control when supported, and source-backed original PDF/HTML/ZIP links. This is an approved **reading edition** and style baseline, not screenplay or shot Save/Lock approval. The two 25-position selections are Block 01 Mini 01 and Block 02 Mini 01, not every Mini-Block in those Blocks. Verify current Library content and any independent export hash discrepancies instead of inventing a successful readback. The v0.8.38 Skin V1 design system and the four HOME choices remain unchanged.


## v0.8.42 — Production Design entry

From Storyboard → REEL/ONCE → Production Design, provide Characters, Worlds and Layout Sheets without changing the four HOME choices or unapproved Skin V1 hierarchy. Route to ../plotpickle-design/SKILL.md for source-listed character/scene choices and new versioned prompt/candidate/review sidecars. Distinguish empty template, prompt prepared, byte/header checked, human visually accepted and persistently saved/locked. A full layout alone grants no visual approval. If the user asks for an image, use the actual image tool and inspect the result. No generation happens from simply entering Production Design. The original PPF is never rewritten by the offline stage/review tools.


## v0.8.43 — creator-approved reference Save/Lock

Route explicit approval, Save/Lock, 50-shot scope audits and actual design reference registration to `../plotpickle-approval/SKILL.md`. Creator approval starts a verified Save→Lock transaction: it is not itself a completed PPF write. Keep character/world reference locks separate from native storyboard shot locks. Never count a five-panel composite as five individual native shot images. Use Plugin Creator to update the plugin; do not embed private PPFs or artwork or claim GitHub CI verification.


## HOME project opening — owner direction, v0.8.48

HOME is the only project-opening entry. Preserve the four existing primary cards and add one quiet Open ChatGPT Library link below them, not a fifth card and not an import form. The live HOME route is https://plotpickle-studio.avairis.chatgpt.site/home and the MCP tool is `open_studio_home`. Review / Editor has a HOME navigation action and no file inputs. Continue Review / Continue Editor resume the same source and draft; navigation must never reset the cut, score or review state.

On a real Library selection in chat, resolve the exact selected project, its current saved PPF or portable package, screenplay, registered images, design references, original videos, audio and current draft using native Library tools. Reopen source and actual linked bytes; compare the complete manifest against accessible files and hashes. Present loaded / missing / stale / unassigned counts before saying all files are loaded. Do not assume similarly titled files, composites, URLs or historic chat requests are current linked assets. The saved story title is authoritative.

A dropped PPF or screenplay goes directly to Elara in chat for read-only inspection and the established screenplay → storyboard → visuals → produce workflow. Do not ask the creator to extract JSON or manually select 25 WebPs in a web form. Use headless guarded source import only after Elara has the real source and bytes, and preserve an existing matching draft.

The standalone Library link opens Library but does not itself return a selected file or grant the hosted Site Library access. This environment exposes no supported Sites eligibility/discovery operation for the Library connector, so automatic browser Library picker → all-files-loaded is NOT implemented. Native chat-side Library tools remain available. Report the automatic handoff as pending; never emulate it with cached creator data for another user or a fake successful selection.

