---
name: plotpickle-unified-application
description: Use when someone opens, launches, installs, continues, reviews, or asks to consolidate PlotPickle as one ChatGPT-native interactive filmmaking application guided by Elara.
---

## Current hosted core routing — November 11, 2026

Use `../plotpickle-studio/references/hosted-core.md` for the current Sites-hosted core and Elara handoff. This routing supersedes older source-only, independent-host migration, and mandatory separate Transfer setup descriptions. Keep the original plugin and App connection, the approved Skin V1 hierarchy, and the existing project truth rules. Elara converses in this ChatGPT conversation while the application runs beside it; do not add a website chatbot or request an API key for chat.

# PlotPickle — one application inside ChatGPT (owner-approved, 2026-11-11)

## Product identity and entry

PlotPickle is one user-facing ChatGPT-native storytelling APPLICATION delivered as one installable plugin, not a personal-only story reader and not a standalone website. Elara is the persistent conversational guide across every screen. Do not ask an ordinary user to install PlotPickle Relay, a separate Transfer/Site plugin, a Windows desktop app, a factory tunnel or a second PlotPickle Studio plugin. Internal components can remain separated, but each is an implementation detail of the single user-facing experience.

Always preserve the approved Skin V1 HOME in the chat: Meet Elara / Learn / Storyboard / Connected Services, in that order. Storyboard opens REEL and ONCE sharing the canonical PPF engine. Follow `../plotpickle-welcome/SKILL.md`, `../plotpickle-skin-v1/SKILL.md`, and `../plotpickle-studio/SKILL.md` for exact layouts, not ad hoc cards. Display the name "PlotPickle" to users when possible; keep the existing plugin package identity until a guarded migration is proven. No new compulsory login or site navigation for everyday use.

## Live interactive route

When the authenticated PlotPickle Studio MCP tools are actually available to the installed plugin, invoke `open_studio_home` to open the embedded HOME. For a request to edit, review, approve, resubmit or resume a saved editorial draft, invoke `open_studio_review_editor`; for inspection, use `studio_get_state`. These existing tools belong to the Site-backed MCP service; merely linking to the Site is not an embedded app and a skill's mention of a tool is not proof of an installation or connection. If tools are not actually available, use the equivalent approved in-chat Skin V1 presentation and say the interactive backend is not connected rather than showing a fictional working editor.

Site hosting is permitted as infrastructure but must not become a competing HOME or mandatory browser destination. A private Site plugin is not automatically installable by other users. Keep Site deployment, App/plugin registration and host authentication separate from release acceptance. Opening an MCP tool is read-only and never silently changes approval, PPF locks, media or draft.

## Private project selection and continuity

HOME is the only project-opening entry. On a native ChatGPT Library or user-provided PPF/script selection, resolve the actual project and validate its source revision/hash, screenplay passages, shot maps, media byte counts/hashes and permitted files before showing them as loaded. Do not assume that a standalone Library URL returns a file ID or grants Site access. Until a verified picker-to-MCP bridge exists, describe automatic Library selection and recursive media loading as pending, and use an authorized chat-side selected file as the source. Never load one user's private seed for another signed-in user.

Maintain stable authenticated identity, source PPF project ID/revision/hash and editorial revision across HOME, Storyboard, Review and the six-track 24fps Timeline Editor. Preserve six lanes: video, dialogue, action, foley, ambience and music. Retain original media, cut, navigation state, review history and undo where available. A Studio review sidecar is NOT an edit to native PPF Save/Lock; show Human Approved, PPF Saved, PPF Locked and Media Verified independently. Use expected revisions and exact media hashes for any authorized write, with separate independent readback. Resubmit only requests Elara review; it does not purchase generation. No paid provider job without job-specific explicit approval.

## Single-install rollout gates

An internally connected creator account is a pilot, not a public one-install release. Before claiming release for everyone, verify the actual public plugin includes MCP access (not merely a private registered `.app.json` dependency), is installable on a second independent eligible ChatGPT account, opens HOME and Review as embedded MCP App views without a second plugin, permits user-specific project import/resume, and enforces cross-account isolation in the real host. Test Save/Lock persistence and editor readback separately from host UI rendering, verify Library transfer via original bytes and SHA-256, then prepare public submission with the real remote MCP endpoint and required public listing/review materials. Leave existing private plugins and Site IDs intact until parity and rollout succeed; no uninstall, automatic publishing or destructive migration based on this skill alone.

## Acceptance language

Use these exact distinctions: skill route configured; app dependency bound; MCP tools connected; embedded view opened; persisted private project read back; owner-approved native PPF locks verified; second account passed; public plugin published. Do not collapse them into "done". The first existing owner-side embedded HOME/Editor tool invocations establish only that the currently connected MCP service can render those screens in ChatGPT, not that the original skills plugin now automatically bundles that Site's app or that public users can install it.

