---
name: plotpickle-welcome
description: Enter PlotPickle Studio via its published, owner-approved Skin V1 HOME and source-backed storytelling screens.
---

## Current hosted core routing — November 11, 2026

Use `../plotpickle-studio/references/hosted-core.md` for the current Sites-hosted core and Elara handoff. This routing supersedes older source-only, independent-host migration, and mandatory separate Transfer setup descriptions. Keep the original plugin and App connection, the approved Skin V1 hierarchy, and the existing project truth rules. Elara converses in this ChatGPT conversation while the application runs beside it; do not add a website chatbot or request an API key for chat.

# HOME (v0.8.42 — Skin V1, Production Design, Connections, and official reader)

**Always use `../plotpickle-skin-v1/SKILL.md` and its canonical `references/skin-v1.json` to render HOME, Storyboard, Story Map, Mini-Block/25-shot grid or Image Review.** The approved HOME is fixed: brand/header, HOME breadcrumb, one heading, exactly four cards ordered **Meet Elara / Learn / Storyboard / Connected Services**, then quiet Continue Creating only for a current verified story, then status/footer. Use matte black/off-white with restrained purple accent and consistent mobile-friendly spacing; do not reinterpret this hierarchy from scratch.

Storyboard has equally weighted REEL and ONCE above source-verified Your Stories and a quiet Create Story. Both use one PPF engine, 81 lessons, Character/World builders, Assets, Posters, Reports, Pitch Deck, animatic, editing, Sound and production. Story Map has 4 Acts ×3 Sequences ×2 Blocks; Mini-Block has exactly 4 mini selectors and 5×5 shot slots; Image Review has the four independent source-status rows. Delegate truth, actions and source readback to existing reader/navigator/review skills. A preview selection cannot claim a saved project change; a real action requires explicit operation with independently checked readback. No generated music, video or spend from opening a view.

For ONCE, preserve factual memories and privacy and ask consent before invented reenactments. For Connected Services (Connections), show Suno, fal, PlotPickle Transfer, BUZZ and Modem in that order. PlotPickle Transfer is a per-creator private Site-hosted MCP companion, required only for automatic original fal-video imports to ChatGPT Library, not for generating videos, writing or storyboarding. Present Set up Site and Verify connection as distinct actions; never mark it connected from the static catalogue, invent a Site URL or claim a transfer succeeded without live authorized tool + original-byte Library readback. Preserve the existing Suno, fal, BUZZ and Modem behaviors. These additional interfaces are not yet visually locked under Skin V1. The retired hosted sidebar is not part of v0.8.39; ordinary use stays in ChatGPT on phone or desktop, without mandatory Windows app or GitHub.

On REEL entry use `fixedSurfaceLayouts.REEL_WORKSPACE_ENTRY` with New Idea / Import Script / Continue Film / Explore Tools. On mobile Storyboard Review, use the approved vertical `MOBILE_STORYBOARD_REVIEW` with source-verified images; do not pretend the older sidebar is hosted. Provide access to a real five-page graphic-novel Mini-Block edition if verified from current authorized Library/Project files. These updates add no automatic PPF writes or credit-consuming provider generation.

**Official Graphic Novel v0.8.39:** when the user opens REEL > Your Stories > The Third Bell, show `Read Graphic Novel` when the real official edition is available. Reopen private Library `/The Third Bell/Graphic Novel/Official Blocks 01-02/`, verify actual ten images and the available original reader/PDF/archive, then use `../plotpickle-official-reader/SKILL.md` for page-by-page reading of 50 captioned panels. Do not hardcode thumbnails or promise that all users have this private Library. A creator-approved reading edition does not update PPF Save/Lock or rewrite contradictory screenplay source.


**Production Design v0.8.42**: Storyboard → REEL/ONCE → Production Design offers Character Builder, World Builder, Layout Sheets. See ../plotpickle-design/SKILL.md. Character sheets have nine distinct square view positions, and world sheets six landscape positions. Review proof statuses separately: source confirmed, proposed design, image bytes/header checked, human visual approval and any native PPF save/lock. Entry is read-only; show user-authorized image generation only when explicitly requested.


## v0.8.43 — creator-approved reference Save/Lock

Route explicit approval, Save/Lock, 50-shot scope audits and actual design reference registration to `../plotpickle-approval/SKILL.md`. Creator approval starts a verified Save→Lock transaction: it is not itself a completed PPF write. Keep character/world reference locks separate from native storyboard shot locks. Never count a five-panel composite as five individual native shot images. Use Plugin Creator to update the plugin; do not embed private PPFs or artwork or claim GitHub CI verification.

