PlotPickle Site retirement reference adapter, 2026-11-11.
Source: /PlotPickle/Studio Integration/PlotPickle-Library-Bridge-Integration-2026-11-11.zip (creator Library).
Contains reference project-bridge.mjs and 18 Node tests, not deployed host code.
No PPF project data, media bytes, private creator registry or account credentials are in this plugin skill. Real Site backend source and data must be exported in ChatGPT Work.
Retain original installed App association until independent-hosted MCP and account isolation pass acceptance. Public upload must be a separate package using a verified remote MCP endpoint per current plugin submission requirements.
