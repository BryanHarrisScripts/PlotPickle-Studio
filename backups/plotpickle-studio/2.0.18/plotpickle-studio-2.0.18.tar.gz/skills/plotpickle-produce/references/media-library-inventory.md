# Recovery and classification contract (v0.8.44)

The creator wants all historically approved and awaiting-review PlotPickle images/videos available in ChatGPT personal Library, organized without losing an original. Always begin with a scoped Files Library inventory, connected fal account media/history and current canonical PPF/approval receipts. Conversation statements are leads, not proof of current accessible media bytes.

Classification precedence:

1. VERIFIED LOCKED: reopen current PPF/portable package, verify project ID/revision/hash, per-shot or design-ref mapping, saved and locked records, actual file bytes/hash/decode. An archive of a previous rev is evidence of that rev, not proof current canonical PPF advanced.
2. CREATOR APPROVED — REGISTRATION PENDING: explicit selection/approval but no evidence of per-shot/native Save→Lock readback. A 25-cell composite page is one image, not 25 independent image files.
3. REVIEW PENDING: actual candidate bytes and source mapping exist but creative acceptance not evidenced.
4. REMOTE ORIGINAL — TRANSFER PENDING: fal completed generation and URL exist, but direct Library original upload and independent byte/SHA readback are not completed.
5. UNCLASSIFIED: anonymous asset files, old examples, provider items without verified story/shot association, or historical conversational references without present raw bytes.

Preserve originals, original names, hashes, approval records and story revision. Copy, don't destructively move, to `/PlotPickle/Stories/<Story>/...`. Never claim a Library copy is SHA-verified until independent re-materialization compares bytes. Don't transfer arbitrary files into approved folders based on filename alone. Do not delete superseded images without explicit approval. Record what remains absent and request no unnecessary regeneration.

Known November 10 inventory: The Third Bell rev010 has 25 independent locked storyboard WebPs for B01/M01; 4 locked design refs; 10 graphic-novel pages from an approved reading edition; one selected B02/M01 25-panel overview with no per-shot native Save/Lock; real Shot 01 original already in Library (8,495,321 bytes) with 24fps derivative; Shot 02/03 originals still fal-provider-only, and an older fal video requires mapping. Brotherly Love historically mentions 120+ images and two animatics, but these full-media originals have not been verified in today's recovery; one character-sheet PNG and PPF were organized under review pending. Afterglow is documented historically, but its full image/video set has not been recovered. Treat all these as timestamped facts and recheck on future turns.

The six-track source-pinned timeline and offline animatic are not a native editor Service or creative master; persist their receipts in Library only after real file upload and readback.
