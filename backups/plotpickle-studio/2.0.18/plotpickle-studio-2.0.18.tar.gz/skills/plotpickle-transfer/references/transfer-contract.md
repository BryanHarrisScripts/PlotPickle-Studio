# Transfer provenance and acceptance (merged from standalone Relay v0.1.1)

`source-verified`: live fal asset maps to completed authorized job and original HTTPS MP4 URL.
`bytes-unavailable`: source URL exists, but actual bytes cannot be fetched in the authorized host.
`bytes-fetched`: original bytes downloaded with bounded size, MP4 header and SHA-256 verified.
`library-uploaded-unverified`: host upload reports a Library file ID but independent persisted-file readback is pending.
`verified-in-library`: authorized Library readback/materialization matches exact size and SHA-256 of the downloaded original.
`blocked`: explicit source, permission, transport or integrity failure.

Do not call a 30fps provider original a 24fps editorial master. Do not overwrite the source or canonical PPF Save/Lock. The browser client is a prototype; generic public-user filename and cross-account isolation must be implemented and accepted in the Site MCP App before public rollout. Creator-click transport, when supported, does not imply any automatic paid generation.
